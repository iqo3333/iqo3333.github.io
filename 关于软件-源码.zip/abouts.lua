require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.text.*"
import "android.content.Intent"
import "android.net.Uri"
import "android.provider.*"
import "com.androlua.LuaAdapter"
packinfo=this.getPackageManager().getPackageInfo(this.getPackageName(),((32552732/2/2-8183)/10000-6-231)/9)
banbenming=tostring(packinfo.versionName)

nightMode="/data/data/"..activity.getPackageName().."/nightMode.xml"
import "java.io.File"
local aa=(File(nightMode).length())
if aa==0 then
  File(nightMode).createNewFile()
  io.open(nightMode,"w+"):write("false"):close()
 else
  File(nightMode).createNewFile()
  nightMode=io.open(nightMode):read("*a")
end
if nightMode=="true" then
  color1="#FF212121"
  color2="#FFAAAAAA"
  color3="#DDFFFFFF"
  activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xff212121);
  if tonumber(Build.VERSION.SDK) >= 23 then
    activity.getWindow().getDecorView().setSystemUiVisibility(0);
  end
 else
  color1="#FFFFFFFF"
  color2="#FF000000"
  color3="#DD000000"
  activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xffffffff);
  if tonumber(Build.VERSION.SDK) >= 23 then
    activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
  end
end
layout={
  LinearLayout,
  layout_width="fill",
  layout_height="fill",
  orientation="vertical",
  backgroundColor=color1,
  {
    RelativeLayout;
    layout_width="fill";
    paddingBottom="4dp";
    layout_height="48dp";
    paddingTop="4dp";
    gravity="left";
    {
      ImageButton;
      layout_width="30dp";
      style="?android:attr/buttonBarButtonStyle";
      layout_centerVertical="true";
      padding="0dp";
      id="back";
      layout_marginLeft="10dp";
      paddingRight="2dp";
      layout_marginRight="12dp";
      layout_height="fill";
      paddingLeft="2dp";
      src="lua/exit.png";
      background="#00000000";
      colorFilter=color2;
    };
    {
      TextView;
      layout_width="wrap_content";
      text="关于软件";
      layout_centerVertical="true";
      id="title";
      textColor=0xffdd0000;
      layout_height="fill";
      gravity="center";
      textSize="20dp";
      layout_toRightOf="back";
    };
  };
  {
    RelativeLayout,
    layout_width="fill",
    layout_height="wrap",
    layout_marginTop="45dp",
    {
      ImageView,
      id="logo",
      layout_width="75dp",
      layout_height="75dp",
      layout_marginLeft="16dp",
      layout_centerVertical=true,
      layout_alignParentLeft="true",
      src="icon",
    },
    {
      TextView,
      layout_toRightOf="logo";
      layout_marginLeft="8dp",
      layout_marginRight="16dp",
      layout_centerVertical=true,
      text="欢迎使用Pro冲浪！\n提供VIP视频解析、多搜索引擎支持，轻松域名跳转，带来快速、安全的上网体验。",--文本内容
      textSize="16sp",
      textColor=color2,
    }
  },
  {
    TextView,--文本框控件
    layout_width="fill",--布局宽度
    layout_height="40dp",--布局高度
    gravity="center",--重力属性--顶:top--中:center--左:left--右:right--底:bottom
    text="全部参数",--文本内容
    textSize="18sp",--文本大小
    textColor="0xffdd0000",--文本颜色
    onClick=function()
      device_model = Build.MODEL
      version_xtbb = Build.VERSION.RELEASE
      version_cpxh = Build.PRODUCT
      version_bbxx = Build.DISPLAY
      version_cpmc = Build.PRODUCT
      version_xtdz = Build.BRAND
      version_sbcs = Build.DEVICE
      version_kfdh = Build.VERSION.CODENAME
      version_sdk = Build.VERSION.SDK
      version_cpu = Build.CPU_ABI
      version_yjlx = Build.HARDWARE
      version_zjdz = Build.HOST
      version_id = Build.ID
      version_rom = Build.MANUFACTURER
      version_release = Build.VERSION.RELEASE
            local 版本号 = activity.getPackageManager().getPackageInfo(activity.getPackageName(),0).versionName
      程序包名=activity.getPackageName()
      内部版本号=tostring(this.getPackageManager().getPackageInfo(this.getPackageName(),((782268899/2/2-8183)/10000-6-231)/9).versionCode)
      import "android.provider.Settings$Secure"
      android_id = Secure.getString(activity.getContentResolver(), Secure.ANDROID_ID)
      xxx=AlertDialog.Builder(this)
      xxx.setTitle("全部参数")--标题
      xxx.setMessage("应用版本号:"..版本号.."\n\n内部版本号:"..内部版本号.."\n\n包名:"..程序包名.."\n\n手机型号："..device_model.."\n\n安卓版本："..version_xtbb.."\n\n产品型号："..version_cpxh.."\n\n版本显示：" ..version_bbxx.."\n\n系统定制商："..version_xtdz.."\n\n设备参数：" ..version_sbcs.."\n\n开发代号："..version_kfdh.."\n\nSDK版本号:"..version_sdk.."\n\nCPU类型："..version_cpu.."\n\n硬件类型：" ..version_yjlx.."\n\n主机地址:"..version_zjdz.."\n\n生产ID："..version_id.."\n\nROM制造商："..version_rom.."\n\n安卓ID："..android_id)
      xxx.setPositiveButton("复制设备ID",function()--积极按钮
        import "android.content.*"
        activity.getSystemService(Context.CLIPBOARD_SERVICE).setText(android_id)
        提示("已复制设备ID:"..android_id)
        --执行的事件
      end)
      xxx.setNegativeButton("关闭",nil)--消极按钮
      xxx.setCancelable(false)--禁用返回键
      xxx=xxx.show()--显示


    end
  },
  {
    RelativeLayout,
    layout_width="fill",
    layout_height="fill",
    layout_marginTop="10dp",
    {
      ListView,
      id="list",
      layout_width="fill",
      layout_marginTop="20dp",
      layout_marginLeft="6dp",
      layout_marginRight="6dp",
      dividerHeight="0dp",
    },
  },
}

activity.setContentView(loadlayout(layout))

adpd={
  {
    img={
      src="lua/Author.png",
    },
    title={
      text="作者",
    },
    content={
      text="@Pro_Pro",
    },
  };
  {
    img={
      src="lua/3.png",
    },
    title={
      text="官网",
    },
    content={
      text="点击跳转官网",
    },
  };
  {
    img={
      src="lua/7.png",
    },
    title={
      text="源码开放",
    },
    content={
      text="“关于应用”页面源码开放",
    },
  };
  {
    img={
      src="lua/6.png",
    },
    title={
      text="免责声明",
    },
    content={
      text="使用本软件即代表您阅读并同意免责声明",
    },
  };
  {
    img={
      src="lua/4.png",
    },
    title={
      text="内核版本",
    },
    content={
      text="Chrome 135.0.7049.41",
    },
  };
  {
    img={
      src="lua/5.png",
    },
    title={
      text="版权信息",
    },
    content={
      text="©Pro_Pro 2023-Present. All Rights Reserved",
    },
  };
}
items={
  LinearLayout,
  layout_width="fill",
  orientation="horizontal",
  gravity="center|left",
  {
    ImageView,
    id="img",
    layout_margin="10dp",
    layout_width="30dp",
    layout_height="30dp",
    colorFilter=color2,
  },
  {
    LinearLayout,
    layout_width="fill",
    layout_marginLeft="10dp",
    layout_marginRight="10dp",
    orientation="vertical",
    {
      TextView,
      id="title",
      textColor=color2,
      textSize="15sp",
    },
    {
      TextView,
      id="content",
      textColor=color3,
      textSize="12sp",
    },
  },
}

onclick={
  function()
    function Toast消息(文本)
  local tsxx=Toast.makeText(this,文本,Toast.LENGTH_SHORT)
  tsxx.show()
  return tsxx
end
Toast消息("作者：@Pro_Pro")
  end,
  function()
    this.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.iqo3333.cn")))
  end,
  function()
    this.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.123pan.com/s/UpF5Vv-SHood")))   
  end,
  function()
    this.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.iqo3333.cn/disclaimer")))
  end,
  function()
    function Toast消息(文本)
  local tsxx=Toast.makeText(this,文本,Toast.LENGTH_SHORT)
  tsxx.show()
  return tsxx
end
Toast消息("Chrome 135.0.7049.41")
  end,
  function()
    function Toast消息(文本)
  local tsxx=Toast.makeText(this,文本,Toast.LENGTH_SHORT)
  tsxx.show()
  return tsxx
end
Toast消息("©Pro_Pro 2023-Present. All Rights Reserved")
  end
}

adapter=LuaAdapter(this,adpd,items)
list.Adapter=adapter
list.onItemClick=function(adp,view,pos,id)
  if onclick[id] then
    onclick[id]()
  end
end

back.onClick=function()
  activity.finish()
end